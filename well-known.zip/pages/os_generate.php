<?php
echo '<div class="container py-4"><div class="alert alert-info">OS é gerada ao aprovar o orçamento.</div></div>';
