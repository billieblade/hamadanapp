<?php
echo '<div class="container py-4"><h3>Dashboard</h3><p>Bem-vindo! Use o menu para navegar.</p></div>';
