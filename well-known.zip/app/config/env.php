<?php
return [
  'db' => [
    'host' => 'localhost',
    'name' => 'cervejac_hamadanapp',
    'user' => 'cervejac_hamadanappuser',
    'pass' => '+J2O_O+O7zx8',
    'charset' => 'utf8mb4'
  ],
  'app' => [
    'base_url' => 'http://hamadanapp.cervejacomogros.com.br',
    'timezone' => 'America/Sao_Paulo'
  ]
];
