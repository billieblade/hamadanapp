<?php
require __DIR__.'/app/auth.php';
logout();
